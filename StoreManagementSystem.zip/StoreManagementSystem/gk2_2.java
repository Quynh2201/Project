package StoreManagementSystem;

import java.awt.*;

class Circle1{
    double radius; String color;
    Circle1(){
        this.radius = radius;
        this.color = color;
    }
    Circle1(double radius){
        this.radius = radius;
    }
    Circle1(double radius, String color){
        this.radius = radius;
        this.color = color;
    }
    void setRadius(double radius){
        this.radius = radius;
    }
    double getRadius(){
        return radius;
    }
    void setColor(String color){
        this.color = color;
    }
    String getColor(){
        return color;
    }
    String tostring(){
        return radius + ", " + color;
    }
    double getArea(){
        return 3.14 * radius * radius;
    }
}

class Cylinder extends Circle1{
    double height;
    Cylinder(){
        super();
        height = 1.0;
    }
    Cylinder(double height){
        this.height = height;
    }
    Cylinder(double radius, double height){
        super(radius);
        this.height = height;
    }
    Cylinder(double radius, double height, String color){
        super(radius, color);
        this.height = height;
    }
    void setHeight(double height){
        this.height = height;
    }
    double getHeight(){
        return height;
    }
    String tostring(){
        return height + ", " + radius + ", " + color;
    }
    double getVolume(){
        return height * this.getArea();
    }
}

public class gk2_2 {
    public static void main(String[] args){

    }
}
