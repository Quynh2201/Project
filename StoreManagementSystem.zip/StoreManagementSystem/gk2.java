package StoreManagementSystem;
import java.lang.Math;
class Point{
    int x, y;
    Point(int x, int y){
        this.x = x;
        this.y = y;
    }
    void setX(int x){
        this.x = x;
    }
    int getX(){
        return x;
    }
    void setY(int y){
        this.y = y;
    }
    int getY(){
        return y;
    }
    String tostring(){
        return "(" + Integer.toString(x) + ", " + Integer.toString(y) + ")";
    }
    void setXY(int x, int y){
        this.x = x;
        this.y = y;
    }
    int[] getXY(){
        return new int[]{x, y};
    }
    double distance(int x, int y){
        return Math.sqrt((x - this.x) * (x - this.x) + (y - this.y) * (y - this.y));
    }
    double distance(Point p){
        return Math.sqrt((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y));
    }
    double distance(){
        return Math.sqrt(x * x + y * y);
    }
}

class Circle extends Point{
    Point center; double radius;
    Circle(){
        super(0, 0);
        Point center = new Point(0, 0);
        radius = 1.0;
    }
    Circle(int xCenter, int yCenter, double radius){
        super(xCenter, yCenter);
        center.x = xCenter;
        center.y = yCenter;
        this.radius = radius;
    }
    Circle(Point center, double radius){
        super(center.x, center.y);
        this.radius = radius;
        this.center = center;
    }
    void setRadius(double radius){
        this.radius = radius;
    }
    double getRadius(){
        return radius;
    }
    void setCenter(Point p){
        center = p;
    }
    Point getCenter(){
        return center;
    }
    void setCenterX(int x){
        center.x = x;
    }
    int getCenterX(){
        return center.x;
    }
    void setCenterY(int y){
        center.y = y;
    }
    int getCenterY(){
        return center.y;
    }
    void setCenterXY(int x, int y){
        center.x = x;
        center.y = y;
    }
    int[] getCenterXY(){
        return center.getXY();
    }
    String tostring(){
        return "Circle[Center=(" + Integer.toString(center.x) + "," + Integer.toString(center.y) + ",radius=" + radius + "]";
    }
    double getArea(){
        return 3.14 * radius * radius;
    }
    double getCircumference(){
        return 3.14 * 2 * radius;
    }
    double distance(Circle c){
        return Math.sqrt((x - c.center.x) * (x - c.center.x) + (y - c.center.y) * (y - c.center.y));
    }

}
public class gk2 {
    public static void main(String[] args){

    }
}
